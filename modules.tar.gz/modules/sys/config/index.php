<?php
session_start();

$page_title="Config";
include"../../../head.php";
?>
<ul id="cmd-buttons">
	<!--<li><a class="button icon chat" href="../../em/clientbanks/clientbanks.php">Client Banks</a></li>
	<li><a class="button icon chat" href="../../em/rentaltypes/rentaltypes.php">Rental Types</a></li>
	<li><a class="button icon chat" href="../../em/housestatuss/housestatuss.php">Unit Status</a></li>
	<li><a class="button icon chat" href="../../em/actions/actions.php">Actions</a></li>
	<li><a class="button icon chat" href="../../em/types/types.php">Property Types</a></li>
	<li><a class="button icon chat" href="../../em/regions/regions.php">Regions</a></li>
	<li><a class="button icon chat" href="../../em/hsedescriptions/hsedescriptions.php">Unit Descriptions</a></li>
	<li><a class="button icon chat" href="../../em/rentalstatuss/rentalstatuss.php">Rental Status</a></li>
	<li><a class="button icon chat" href="../../em/paymentterms/paymentterms.php">Payment Terms</a></li>
	<li><a class="button icon chat" href="../../sys/vatclasses/vatclasses.php">VAT Classes</a></li>-->
	<li><a class="button icon chat" href="../../sys/config/config.php">Configurations</a></li>
	<li><a class="button icon chat" href="../../sys/currencys/currencys.php">Currencies</a></li>
	<li><a class="button icon chat" href="../../sys/currencyrates/currencyrates.php">Currency Rates</a></li>
	<!--<li><a class="button icon chat" href="../../sys/genders/genders.php">Genders</a></li>
	<li><a class="button icon chat" href="../../sys/nationalitys/nationalitys.php">Nationalities</a></li>
	<li><a class="button icon chat" href="../../sys/notifications/notifications.php">Notifications</a></li>
	<li><a class="button icon chat" href="../../sys/paymentmodes/paymentmodes.php">Payment Modes</a></li>
	<li><a class="button icon chat" href="../../sys/purchasemodes/purchasemodes.php">Purchase Modes</a></li>
	<li><a class="button icon chat" href="../../sys/subregions/subregions.php">Sub-Regions</a></li>
	<li><a class="button icon chat" href="../../sys/salemodes/salemodes.php">Sale Modes</a></li>-->
	
</ul>
<?php
include"../../../foot.php";
?>
